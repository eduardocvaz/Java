public class Aluno {
    private String listaTreino;
    private String nome;
    private String cpf;
    private int anoNascimento;

    public String getListaTreino() {
        return this.listaTreino;
    }

    public void setListaTreino(String listaTreino) {
        this.listaTreino = listaTreino;
    }

    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return this.cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public int getAnoNascimento() {
        return this.anoNascimento;
    }

    public void setAnoNascimento(int anoNascimento) {
        this.anoNascimento = anoNascimento;
    }


}
