public class Recepcionistas extends Funcionarios{
    private String diaTrabalho;
    private String horarioTrabalho;


    public Recepcionistas() {
    }


    public String getDiaTrabalho() {
        return this.diaTrabalho;
    }

    public void setDiaTrabalho(String diaTrabalho) {
        this.diaTrabalho = diaTrabalho;
    }

    public String getHorarioTrabalho() {
        return this.horarioTrabalho;
    }

    public void setHorarioTrabalho(String horarioTrabalho) {
        this.horarioTrabalho = horarioTrabalho;
    }


}
