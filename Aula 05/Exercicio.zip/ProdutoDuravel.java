public class ProdutoDuravel extends Produto {
    private int durabilidade;

    public ProdutoDuravel() {
    }

    public int getDurabilidade() {
        return this.durabilidade;
    }

    public void setDurabilidade(int durabilidade) {
        this.durabilidade = durabilidade;
    }

}
